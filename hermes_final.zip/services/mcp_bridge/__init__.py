# Hermes MCP Bridge Package
